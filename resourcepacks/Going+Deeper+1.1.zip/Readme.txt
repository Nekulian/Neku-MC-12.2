Resauce pack for Abyssal Depths

This pack is intended to update the textures from the port of Aquatic Abyss, Abyssal Depths with a newer texture style. You can report bugs on my discord id [The Indominator#9864], support the official Abyssal Depths and all of the devs also, or else.

Yours sincerely, Indom
